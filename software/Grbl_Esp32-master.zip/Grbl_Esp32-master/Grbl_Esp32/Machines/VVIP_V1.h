#define MACHINE_NAME            "VVIP_V1"

#ifdef N_AXIS
        #undef N_AXIS
#endif
#define N_AXIS 4

#define X_STEP_PIN              GPIO_NUM_27
#define X_DIRECTION_PIN         GPIO_NUM_26
#define Y_STEP_PIN              GPIO_NUM_33
#define Y_DIRECTION_PIN         GPIO_NUM_32
#define Z_STEP_PIN              GPIO_NUM_14
#define Z_DIRECTION_PIN         GPIO_NUM_12
#define A_STEP_PIN              GPIO_NUM_16
#define A_DIRECTION_PIN         GPIO_NUM_17
#define STEPPERS_DISABLE_PIN    GPIO_NUM_25


#define SPINDLE_PWM_PIN         GPIO_NUM_4
#define SPINDLE_ENABLE_PIN      GPIO_NUM_4

//#define MODBUS_TX               GPIO_NUM_17
//#define MODBUS_RX               GPIO_NUM_4
//#define MODBUS_CTRL             GPIO_NUM_16

#define X_LIMIT_PIN             GPIO_NUM_34
#define Y_LIMIT_PIN             GPIO_NUM_35
#define Z_LIMIT_PIN             GPIO_NUM_15

#if (N_AXIS == 3)
        #define LIMIT_MASK      B0111
#else
        #define A_LIMIT_PIN     GPIO_NUM_39
        #define LIMIT_MASK      B1111
#endif

#define PROBE_PIN               GPIO_NUM_36
#define COOLANT_MIST_PIN        GPIO_NUM_2
